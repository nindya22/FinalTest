
-- 1. Please create dimension tables dim_user , dim_post , and normalized data from the raw tablesdim_date to store
-- Create dimension table for users
CREATE TABLE dim_user (
  user_id INT NOT NULL,
  user_name VARCHAR(100) NOT NULL,
  country VARCHAR(50) NOT NULL,
  PRIMARY KEY (user_id)
);

-- Insert data into dim_user table
INSERT INTO dim_user
SELECT DISTINCT user_id, user_name, country
FROM raw_users;

-- Create dimension table for posts
CREATE TABLE dim_post (
  post_id INT NOT NULL,
  post_text VARCHAR(500) NOT NULL,
  post_date DATE NOT NULL,
  PRIMARY KEY (post_id)
);

-- Insert data into dim_post table
INSERT INTO dim_post
SELECT DISTINCT post_id, post_text, post_date
FROM raw_posts;

-- Create dimension table for dates
CREATE TABLE dim_date (
  date DATE NOT NULL,
  PRIMARY KEY (date)
);

-- Insert data into dim_date table
INSERT INTO dim_date
SELECT DISTINCT post_date
FROM raw_posts;

-- 2. Populate the dimension tables by inserting data from the related raw tables
-- Populate dim_user table
INSERT INTO dim_user
SELECT user_id, user_name, country
FROM raw_users;
-- Select number of rows in dim_user table
SELECT COUNT(*) FROM dim_user;

-- Populate dim_post table
INSERT INTO dim_post
SELECT post_id, post_text, post_date
FROM raw_posts;
-- Select number of rows in dim_post table
SELECT COUNT(*) FROM dim_post;

-- Populate dim_date table
INSERT INTO dim_date
SELECT DISTINCT post_date
FROM raw_posts;
-- Select number of rows in dim_date table
SELECT COUNT(*) FROM dim_date;


-- 3.  Create a fact table called fact_post_performance to store metrics like post views and likes over time
-- Create fact table fact_post_performance
CREATE TABLE fact_post_performance (
  fact_id INT PRIMARY KEY,
  post_id INT,
  view_count INT,
  like_count INT,
  date_id INT,
  FOREIGN KEY (post_id) REFERENCES dim_post(post_id),
  FOREIGN KEY (date_id) REFERENCES dim_date(date_id)
);

-- Insert data into fact_post_performance
INSERT INTO fact_post_performance (post_id, view_count, like_count, date_id)
SELECT
  p.post_id,
  COUNT(DISTINCT pv.like_id) AS view_count,
  COUNT(DISTINCT l.like_id) AS like_count,
  d.date_id
FROM
  raw_posts p
  LEFT JOIN raw_likes l ON p.post_id = l.post_id
  LEFT JOIN raw_likes pv ON p.post_id = pv.post_id
  LEFT JOIN dim_date d ON p.post_date = d.full_date
GROUP BY
  p.post_id, d.date_id;

-- 4. Populate the fact table by joining and aggregating data from the raw tables
-- Insert data into fact_post_performance
INSERT INTO fact_post_performance (post_id, view_count, like_count, date_id)
SELECT
  p.post_id,
  COUNT(DISTINCT pv.like_id) AS view_count,
  COUNT(DISTINCT l.like_id) AS like_count,
  d.date_id
FROM
  raw_posts p
  LEFT JOIN raw_likes l ON p.post_id = l.post_id
  LEFT JOIN raw_likes pv ON p.post_id = pv.post_id
  LEFT JOIN dim_date d ON p.post_date = d.full_date
GROUP BY
  p.post_id, d.date_id;


-- 5. Please create a fact_daily_posts table to capture the number of posts per user per day
-- Create fact table fact_daily_posts
CREATE TABLE fact_daily_posts (
  fact_id INT PRIMARY KEY,
  user_id INT,
  post_count INT,
  date_id INT,
  FOREIGN KEY (user_id) REFERENCES dim_user(user_id),
  FOREIGN KEY (date_id) REFERENCES dim_date(date_id)
);

-- Insert data into fact_daily_posts
INSERT INTO fact_daily_posts (user_id, post_count, date_id)
SELECT
  user_id,
  COUNT(DISTINCT post_id) AS post_count,
  d.date_id
FROM
  raw_posts
  LEFT JOIN dim_date d ON raw_posts.post_date = d.full_date
GROUP BY
  user_id, d.date_id;


-- 6. Also populate the fact table by joining and aggregating data from the raw tables
-- Insert data into fact_daily_posts
INSERT INTO fact_daily_posts (user_id, post_count, date_id)
SELECT
  user_id,
  COUNT(DISTINCT post_id) AS post_count,
  d.date_id
FROM
  raw_posts
  LEFT JOIN dim_date d ON raw_posts.post_date = d.full_date
GROUP BY
  user_id, d.date_id;

